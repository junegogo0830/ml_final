# -*- coding: utf-8 -*-
"""
13_window_augment_v2.py
시점 윈도우 증강 (합성 아님, 진짜 부분수열) + GraphSAGE 결합.

v2 누수 수정:
  - 모든 샘플(train/test 공통)을 TRAIN_MAX_YEAR(2022) 기준으로 관찰
    * 양성(train): label_year-1 그래프 (train 내 파산은 ≤2021이므로 자연히 ≤2022)
    * 양성(test): min(label_year-1, TRAIN_MAX_YEAR) → 2022 그래프로 제한
      (label_year-1이 2023~2024여도 2022까지만 사용)
    * 음성(train/test): obs_year <= TRAIN_MAX_YEAR(2022) 인 그래프 중 최신
  - v1 버그: test 음성을 max(avail_years)=2025로 뒀더니 SAGE 분포 이동이
    분류 신호로 작동 (음성=2025 임베딩, 양성=2022-2024 임베딩으로 연도가 레이블 역할)
  - 각 샘플에 obs_year 를 '명시적으로' 들고다님 (corp_code 재조회로 꼬이지 않게)
  - 증강 샘플은 원본 샘플의 (obs_year, node_idx) 를 그대로 상속

전제: 09(sequences.npz), 08(graph_nodes/graph_edges) 완료.
"""

import numpy as np
import sqlite3
from pathlib import Path
import warnings
warnings.filterwarnings("ignore")

from sklearn.metrics import roc_auc_score, average_precision_score, roc_curve
import torch
import torch.nn as nn
from torch_geometric.nn import SAGEConv

NPZ = Path(r"C:\Users\juneg\Desktop\ml_db\ml_db\db\sequences.npz")
DB  = Path(r"C:\Users\juneg\Desktop\ml_db\ml_db\db\dart_v2.db")
SEED=42; EPOCHS=80; LR=1e-3; GAMMA=2.0; PATIENCE=12; DEVICE="cpu"; HID=64
MIN_T=2; MAX_T=5
TRAIN_MAX_YEAR=2022     # 09 의 temporal split 경계 (이하 train)
torch.manual_seed(SEED); np.random.seed(SEED)

RATIO_COLS=["debt_ratio","equity_ratio","debt_to_assets","noncurrent_liab_ratio",
"current_ratio","quick_ratio","cash_ratio","roa","roe","operating_margin",
"net_margin","gross_margin","asset_turnover","inventory_turnover",
"interest_coverage_proxy","ocf_to_current_liab","retained_earnings_ratio",
"working_capital_ratio","z_score"]


# ============== 모델 ==============
class FocalLoss(nn.Module):
    def __init__(self,a,g=2.0): super().__init__(); self.a,self.g=a,g
    def forward(self,l,t):
        p=torch.sigmoid(l); ce=nn.functional.binary_cross_entropy_with_logits(l,t,reduction="none")
        pt=p*t+(1-p)*(1-t); at=self.a*t+(1-self.a)*(1-t)
        return (at*(1-pt)**self.g*ce).mean()

class LSTMEncoder(nn.Module):
    def __init__(self,d,h=HID): super().__init__(); self.lstm=nn.LSTM(d,h,batch_first=True)
    def forward(self,x,m):
        o,_=self.lstm(x); i=(m.sum(1)-1).long().clamp(min=0)
        return o[torch.arange(o.size(0)),i]

class TFTEncoder(nn.Module):
    def __init__(self,d,h=HID,heads=4):
        super().__init__(); self.proj=nn.Linear(d,h)
        self.grn=nn.Sequential(nn.Linear(h,h),nn.ELU(),nn.Linear(h,h),nn.Dropout(0.2))
        self.attn=nn.MultiheadAttention(h,heads,batch_first=True); self.norm=nn.LayerNorm(h)
    def forward(self,x,m):
        h=self.proj(x); h=h+self.grn(h)
        a,_=self.attn(h,h,h,key_padding_mask=(m==0)); h=self.norm(h+a)
        i=(m.sum(1)-1).long().clamp(min=0); return h[torch.arange(h.size(0)),i]

ENCODERS={"LSTM":LSTMEncoder,"TFT":TFTEncoder}

class SAGEEnc(nn.Module):
    def __init__(self,d,h=HID):
        super().__init__(); self.c1=SAGEConv(d,h); self.c2=SAGEConv(h,h)
        self.relu=nn.ReLU(); self.drop=nn.Dropout(0.3)
    def forward(self,x,ei):
        h=self.relu(self.c1(x,ei)); h=self.drop(h); return self.c2(h,ei)

class Combined(nn.Module):
    def __init__(self,EncCls,d_seq,d_node):
        super().__init__(); self.enc=EncCls(d_seq); self.sage=SAGEEnc(d_node)
        self.head=nn.Sequential(nn.Linear(HID*2,32),nn.ReLU(),nn.Dropout(0.3),nn.Linear(32,1))
    def forward(self,xb,mb,geb):
        et=self.enc(xb,mb); return self.head(torch.cat([et,geb],1)).squeeze(-1)


def ks_calc(y,s): fpr,tpr,_=roc_curve(y,s); return float(np.max(tpr-fpr))
def boot(y,s,fn,n=1000):
    rng=np.random.default_rng(SEED); idx=np.arange(len(y)); v=[]
    for _ in range(n):
        b=rng.choice(idx,len(idx),replace=True)
        if y[b].sum() in (0,len(b)): continue
        v.append(fn(y[b],s[b]))
    return np.percentile(v,2.5),np.percentile(v,97.5)


def load_graphs(mean,std,lo,hi):
    con=sqlite3.connect(DB); cur=con.cursor(); col=", ".join(RATIO_COLS); graphs={}
    years=[r[0] for r in cur.execute("SELECT DISTINCT year FROM graph_nodes ORDER BY year")]
    for y in years:
        nodes=cur.execute("SELECT corp_code,node_idx FROM graph_nodes WHERE year=? ORDER BY node_idx",(y,)).fetchall()
        cc2idx={cc:i for cc,i in nodes}; n=len(nodes)
        feat=np.zeros((n,len(RATIO_COLS)),dtype=np.float32)
        fmap={r[0]:r[1:] for r in cur.execute(f"SELECT corp_code,{col} FROM financials WHERE year=?",(y,)).fetchall()}
        for cc,i in cc2idx.items():
            vals=fmap.get(cc)
            if vals is None: continue
            v=np.array([np.nan if z is None else float(z) for z in vals])
            v=np.clip(v,lo,hi); v=(v-mean)/std; feat[i]=np.nan_to_num(v,nan=0.0)
        edges=cur.execute("SELECT src,dst FROM graph_edges WHERE year=?",(y,)).fetchall()
        ei=np.array(edges,dtype=np.int64).T if edges else np.zeros((2,0),dtype=np.int64)
        sl=np.arange(n); ei=np.concatenate([ei,np.stack([sl,sl])],axis=1)
        graphs[y]=dict(cc2idx=cc2idx,x=torch.tensor(feat),edge_index=torch.tensor(ei))
    con.close(); return graphs


def main():
    d=np.load(NPZ,allow_pickle=True)
    Xtr,Mtr,ytr,cctr=d["X_train"],d["M_train"],d["y_train"],d["cc_train"]
    Xte,Mte,yte,ccte=d["X_test"],d["M_test"],d["y_test"],d["cc_test"]
    mean,std=d["scaler_mean"],d["scaler_std"]; lo,hi=d["winsor_lo"],d["winsor_hi"]
    graphs=load_graphs(mean,std,lo,hi)
    avail_years=sorted(graphs.keys())

    con=sqlite3.connect(DB)
    lab={cc:(l,dt) for cc,l,dt in con.execute("SELECT corp_code,label,label_date FROM labels")}
    con.close()

    def resolve_obs(cc, is_train):
        """모든 샘플을 TRAIN_MAX_YEAR(2022) 기준으로 관찰. 미래 그래프 전면 금지."""
        l,dt=lab.get(cc,(0,None))
        if l==1 and dt:
            oy=int(dt[:4])-1
            if not is_train:
                # test 양성: label_year-1이 2023~2024여도 2022까지로 제한
                oy=min(oy, TRAIN_MAX_YEAR)
            return oy if oy in graphs and cc in graphs[oy]["cc2idx"] else None
        # 음성: train/test 모두 TRAIN_MAX_YEAR 이하 최신 (test도 동일 기준 적용)
        cand=[y for y in avail_years if y<=TRAIN_MAX_YEAR and cc in graphs[y]["cc2idx"]]
        return max(cand) if cand else None

    def make_map(ccs, is_train):
        """반환: 각 샘플의 (year, node_idx) or None  -- obs_year 명시 보관."""
        out=[]
        for cc in ccs:
            oy=resolve_obs(cc, is_train)
            if oy is not None and cc in graphs[oy]["cc2idx"]:
                out.append((oy, graphs[oy]["cc2idx"][cc]))
            else:
                out.append(None)
        return out

    # 원본 매핑
    tr_map_orig=make_map(cctr, True)
    te_map=make_map(ccte, False)


    # ===== 윈도우 증강: 양성만, (X,M)뿐 아니라 map 도 함께 상속 =====
    def window_augment(X,M,y,maps):
        addX=[]; addM=[]; addy=[]; addmap=[]
        for i in range(len(X)):
            if y[i]!=1 or maps[i] is None:
                continue
            valid=int(M[i].sum())
            if valid<=MIN_T: continue
            start_orig=MAX_T-valid
            for end in range(valid-1, MIN_T-1, -1):
                seg=X[i,start_orig:start_orig+end,:]
                nx=np.zeros_like(X[i]); nm=np.zeros_like(M[i]); off=MAX_T-end
                nx[off:]=seg; nm[off:]=1.0
                addX.append(nx); addM.append(nm); addy.append(1.0)
                addmap.append(maps[i])             # 원본 obs_year/node 그대로 상속
        if not addX:
            return X,M,y,maps
        Xa=np.concatenate([X,np.array(addX,dtype=np.float32)],0)
        Ma=np.concatenate([M,np.array(addM,dtype=np.float32)],0)
        ya=np.concatenate([y,np.array(addy,dtype=np.float32)],0)
        mapa=list(maps)+addmap
        perm=np.random.default_rng(SEED).permutation(len(ya))
        return Xa[perm],Ma[perm],ya[perm],[mapa[k] for k in perm]

    Xa,Ma,ya,tr_map_aug=window_augment(Xtr,Mtr,ytr,tr_map_orig)
    print(f"원본 train {len(ytr)} (양성 {int(ytr.sum())}) "
          f"-> 증강 후 {len(ya)} (양성 {int(ya.sum())})")
    print(f"증강 추가 양성: {int(ya.sum())-int(ytr.sum())}개 (진짜 부분수열)\n")

    d_seq=Xtr.shape[2]; d_node=len(RATIO_COLS)

    def run(EncCls, Xt,Mt,yt,tmap):
        torch.manual_seed(SEED)
        model=Combined(EncCls,d_seq,d_node).to(DEVICE)
        opt=torch.optim.Adam(model.parameters(),lr=LR,weight_decay=1e-4)
        crit=FocalLoss(float(1-yt.mean()),GAMMA)
        Xtt=torch.tensor(Xt); Mtt=torch.tensor(Mt); ytt=torch.tensor(yt)
        Xee=torch.tensor(Xte); Mee=torch.tensor(Mte)
        def gemb(mp,nrow):
            cache={y:model.sage(graphs[y]["x"],graphs[y]["edge_index"]) for y in graphs}
            g=torch.zeros(nrow,HID)
            for i,m in enumerate(mp):
                if m: g[i]=cache[m[0]][m[1]]
            return g
        best_pr,best_state,wait=0,None,0
        for ep in range(EPOCHS):
            model.train(); opt.zero_grad()
            g0=gemb(tmap,len(Xt))
            if ep==0: print(f"[13 diag] geb mean={g0.mean().item():.6f} std={g0.std().item():.6f} nonzero_rows={int((g0.abs().sum(1)>0).sum())}")
            loss=crit(model(Xtt,Mtt,g0),ytt)
            if ep==0: print(f"[13 diag] ep0 loss={loss.item():.6f}")
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(),1.0); opt.step()
            model.eval()
            with torch.no_grad(): s=torch.sigmoid(model(Xee,Mee,gemb(te_map,len(Xte)))).numpy()
            pr=average_precision_score(yte,s)
            if pr>best_pr: best_pr,best_state,wait=pr,{k:v.clone() for k,v in model.state_dict().items()},0
            else:
                wait+=1
                if wait>=PATIENCE: break
        if best_state: model.load_state_dict(best_state)
        model.eval()
        with torch.no_grad(): s=torch.sigmoid(model(Xee,Mee,gemb(te_map,len(Xte)))).numpy()
        roc=roc_auc_score(yte,s); pr=average_precision_score(yte,s)
        return dict(roc=roc,pr=pr,gini=2*roc-1,ks=ks_calc(yte,s),pr_ci=boot(yte,s,average_precision_score))

    print("="*64)
    print("윈도우 증강 전/후 (LSTM+SAGE, TFT+SAGE) — 누수수정 v2")
    print("="*64)
    for ename,EncCls in ENCODERS.items():
        print(f"\n[{ename}+SAGE 증강 전]")
        r0=run(EncCls,Xtr,Mtr,ytr,tr_map_orig)
        print(f"  ROC {r0['roc']:.4f} PR {r0['pr']:.4f} Gini {r0['gini']:.4f} KS {r0['ks']:.4f}")
        print(f"[{ename}+SAGE 증강 후]")
        r1=run(EncCls,Xa,Ma,ya,tr_map_aug)
        ci=r1['pr_ci']
        print(f"  ROC {r1['roc']:.4f} PR {r1['pr']:.4f} Gini {r1['gini']:.4f} KS {r1['ks']:.4f}"
              f"  PR Δ {r1['pr']-r0['pr']:+.4f}  CI[{ci[0]:.3f},{ci[1]:.3f}]")

    print("\n참고: 증강 전 숫자가 12번(LSTM+SAGE PR~0.43)과 비슷해야 정상.")
    print("수정 후에도 0.6~0.9 처럼 튀면 시계열(sequences.npz) 누수 점검 필요.")
    print("(09_sequences.py에서 test 음성의 obs_year가 2022 초과인지 확인할 것)")


if __name__=="__main__":
    main()